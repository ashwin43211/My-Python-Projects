from tkinter import *
import math
# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
list_check = []
reps = 0
timer = None


# ---------------------------- TIMER RESET ------------------------------- # 
def reset_time():
    global reps
    window.after_cancel(timer)
    label_timer.config(text="Timer")
    label_tick.config(text="")
    canvas.itemconfig(timer_text, text="00:00")
    reps = 0

# ---------------------------- TIMER MECHANISM ------------------------------- # 


def start_timer():
    global reps
    reps += 1
    work_second = WORK_MIN*60
    short_break_second = SHORT_BREAK_MIN*60
    long_break_second = LONG_BREAK_MIN*60

    if reps == 1 or reps == 3 or reps == 5 or reps == 7:
        label_timer.config(text="Work", fg=GREEN, bg=YELLOW, font=(FONT_NAME, 45, "bold"))
        count_down(work_second)
    elif reps == 2 or reps == 4 or reps == 6:
        label_timer.config(text="Break", fg=PINK, bg=YELLOW, font=(FONT_NAME, 45, "bold"))
        count_down(short_break_second)
    elif reps == 8:
        label_timer.config(text="Break", fg=RED, bg=YELLOW, font=(FONT_NAME, 45, "bold"))
        count_down(long_break_second)
# ---------------------------- COUNTDOWN MECHANISM ------------------------------- # 


def count_down(count):
    count_min = math.floor(count/60)
    count_sec = count % 60

    if count_sec < 10:
        count_sec = f"0{count_sec}"
        # in this what we have done is that if the sec is <10,then it would replace count with a string above like this.
        # This won't give error coz, after printing in 33rd line its again initiated with a integer, so the type of
        # the variable will change to int and then in 36th line it will change to string. This is because of dynamic
        # programming

    canvas.itemconfig(timer_text, text=f"{count_min}:{count_sec}")
    if count > 0:
        global timer
        timer = window.after(10, count_down, count - 1)
    else:
        marks = ""
        work_session = math.floor(reps/2)
        for _ in range(work_session):
            marks += "✅"
        label_tick.config(text=marks)
        start_timer()
# ---------------------------- UI SETUP ------------------------------- #


window = Tk()
window.title("Pomodoro")
window.config(bg=YELLOW)
window.config(padx=100, pady=50)

# Label Section
label_timer = Label(text="Timer", fg=GREEN, bg=YELLOW, font=(FONT_NAME, 45, "bold"))
label_timer.grid(row=0, column=2)
label_setup = Label(text="hi", fg=YELLOW, bg=YELLOW, font=(FONT_NAME, 35, "bold"))
label_setup.grid(row=4, column=2)
label_tick = Label(fg=GREEN, bg=YELLOW, font=(FONT_NAME, 25, "bold"))
label_tick.grid(row=5, column=2)

# Canvas Section
canvas = Canvas(width=210, height=235)
canvas.config(bg=YELLOW, highlightthickness=0)

photo = PhotoImage(file="tomato.png")
canvas.create_image(103, 115, image=photo)
timer_text = canvas.create_text(103, 130, text="00:00", fill="white", font=(FONT_NAME, 35, "bold"))
canvas.grid(row=2, column=2)

# Button Section
button_start = Button(text="Start", font=(FONT_NAME, 12, "bold"), command=start_timer, borderwidth=0)
button_start.grid(row=3, column=1)
button_reset = Button(text="Reset", font=(FONT_NAME, 12, "bold"), command=reset_time, borderwidth=0)
button_reset.grid(row=3, column=3)

window.mainloop()
