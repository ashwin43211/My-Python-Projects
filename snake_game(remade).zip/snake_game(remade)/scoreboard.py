from turtle import Turtle

COLOR = "white"
FONT = ("Arial", 16, "normal")
ALIGN = "center"

class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        with open("highest_score.txt") as file:
            self.highest_score = int(file.read())
        self.score = 0
        self.penup()
        self.hideturtle()
        self.color(COLOR)
        self.print_board()

    def keep_track(self):
        self.clear()
        self.score += 1
        self.print_board()

    def print_board(self):
        self.setposition(0, 275)
        self.write(f"Score : {self.score}   High Score : {self.highest_score}", True, align=ALIGN, font=FONT)

    def gameover(self):
        self.penup()
        self.setposition(0, 0)
        self.write(f"GAME OVER", True, align=ALIGN, font=FONT)

    def reset(self):
        self.clear()
        if self.score > self.highest_score:
            self.highest_score = self.score
            with open("highest_score.txt", mode="w") as file:
                file.write(str(self.highest_score))
        self.score = 0
        self.print_board()

