from turtle import Turtle

SIZE = 3
COLOR = "white"
SHAPE = "circle"
SPEED = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0


class Snake(Turtle):
    def __init__(self):
        super().__init__()
        self.turtle_name = []
        self.location = [(0, 0), (-20, 0), (-40, 0)]
        self.create_snake()
        self.head = self.turtle_name[0]

    def create_snake(self):
        for i in range(SIZE):
            block = Turtle()
            block.penup()
            block.color(COLOR)
            block.shape(SHAPE)
            block.goto(self.location[i])
            self.turtle_name.append(block)

    def extend_snake(self):
        xcor = self.turtle_name[-1].xcor()
        ycor = self.turtle_name[-1].ycor()
        block = Turtle()
        block.penup()
        block.shape(SHAPE)
        block.color(COLOR)
        block.goto(xcor-20, ycor)
        self.turtle_name.append(block)

    def move_snake(self):
        for i in range(len(self.turtle_name)-1, 0, -1):
            new_x = self.turtle_name[i-1].xcor()
            new_y = self.turtle_name[i-1].ycor()
            self.turtle_name[i].goto(new_x, new_y)
        self.turtle_name[0].forward(SPEED)

    def reset(self):
        for i  in self.turtle_name:
            i.goto(1000, 1000)
        self.turtle_name.clear()
        self.create_snake()
        self.move_snake()
        self.head = self.turtle_name[0]

    def go_up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def go_down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def go_left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def go_right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)

