from turtle import Turtle
import random

COLOR = "blue"
SHAPE = "turtle"


class Food(Turtle):
    def __init__(self):
        super().__init__()
        self.shape(SHAPE)
        self.color(COLOR)
        self.penup()
        self.shapesize(stretch_wid=1.0, stretch_len=1.0)
        self.speed("fastest")
        self.refresh()

    def refresh(self):
        xcor = random.randint(-270, 270)
        ycor = random.randint(-270, 270)
        self.goto(xcor, ycor)
