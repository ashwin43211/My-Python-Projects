from turtle import Screen
from snake import Snake
from food import Food
from scoreboard import Scoreboard
import time

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("Snake Game")
screen.tracer(0)

is_game_over = False

snake = Snake()
food = Food()
score = Scoreboard()

screen.update()


screen.listen()
screen.onkey(key="w", fun=snake.go_up)
screen.onkey(key="s", fun=snake.go_down)
screen.onkey(key="a", fun=snake.go_left)
screen.onkey(key="d", fun=snake.go_right)

screen.onkey(key="W", fun=snake.go_up)
screen.onkey(key="S", fun=snake.go_down)
screen.onkey(key="A", fun=snake.go_left)
screen.onkey(key="D", fun=snake.go_right)

screen.onkey(key="Up", fun=snake.go_up)
screen.onkey(key="Down", fun=snake.go_down)
screen.onkey(key="Left", fun=snake.go_left)
screen.onkey(key="Right", fun=snake.go_right)

screen.onkey(key="c", fun=screen.bye)
screen.onkey(key="C", fun=screen.bye)

while is_game_over is not True:
    screen.update()
    time.sleep(0.2)
    snake.move_snake()

    if snake.head.distance(food) < 20:
        food.refresh()
        score.keep_track()
        snake.extend_snake()

    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        score.gameover()
        time.sleep(0.5)
        score.reset()
        snake.reset()

    for i in snake.turtle_name[1:]:
        if i == snake.head:
            pass
        elif snake.head.distance(i) < 10:
            score.gameover()
            time.sleep(0.5)
            score.reset()
            snake.reset()

screen.exitonclick()
