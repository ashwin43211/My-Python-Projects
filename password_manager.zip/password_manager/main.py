from tkinter import *
from tkinter import messagebox
import random
import pyperclip
import json

FONT_NAME = "Courier"
YELLOW = "#f7f5dd"

letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
           'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
           'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']
dataframe = {}

# ---------------------------- PASSWORD SEARCH ------------------------------- #


def find_password():
    try:
        with open("data.json", mode="r") as data:
            new_data = json.load(data)
            try:
                password = new_data[textbox_website.get()]
            except KeyError:
                messagebox.showerror(title=f"Error : {textbox_website.get()}", message=f"Password for {textbox_website.get()} not found")
            else:
                messagebox.showinfo(title=f"{textbox_website.get()}", message=f"Email/Username : {password['email']}\n\n Password : {password['password']}")
                pyperclip.copy(password['password'])

    except FileNotFoundError:
        with open("data.json", mode="w") as data:
            json.dump(dataframe, data, indent=4)

# ---------------------------- PASSWORD GENERATOR ------------------------------- #


def create_password():
    textbox_password.delete(0, END)
    random_alphabet = [random.choice(letters) for _ in range(random.randint(5, 7))]
    random_numbers = [random.choice(numbers) for _ in range(random.randint(2, 5))]
    random_symbols = [random.choice(symbols) for _ in range(random.randint(2, 5))]

    random_password = random_alphabet + random_numbers + random_symbols

    # for shuffling the characters in the string and then in ready_password, each character is extracted and the joined
    # as a string in a new variable

    random.shuffle(random_password)
    ready_password = "".join(random_password)
    textbox_password.insert(0, ready_password)
    pyperclip.copy(ready_password)


# ---------------------------- SAVE PASSWORD ------------------------------- #


def save():
    global dataframe
    data_list = []
    website = textbox_website.get()
    username = textbox_username.get()
    password = textbox_password.get()
    data_list.append(username)
    data_list.append(password)
    dataframe = {
        website: {
            "email": username,
            "password": password,
        }
    }

    if len(website) == 0 or len(username) == 0 or len(password) == 0 or website == " " or username == " " or password == " ":
        messagebox.showinfo(title="Warning", message="Don't leave any field blank")
    else:
        is_ok = messagebox.askokcancel(title=f"{website}", message=f"Confirm the data :\n\n Email/Username : {username}\n\n Password : {password}")

        if is_ok:
            try:
                with open("data.json", mode="r") as data:
                    new_data = json.load(data)

            except FileNotFoundError:
                with open("data.json", mode="w") as data:
                    json.dump(dataframe, data, indent=4)

            else:
                new_data.update(dataframe)
                with open("data.json", mode="w") as data:
                    # data.write(f"{website} : {username} : {password}\n")
                    json.dump(new_data, data, indent=4)

            finally:
                textbox_website.delete(0, END)
                textbox_password.delete(0, END)
                messagebox.showinfo(title="Conformation", message="Data Saved Successfully")

# ---------------------------- UI SETUP ------------------------------- #


# Window setup
window = Tk()
window.title("Password Manager")
window.config(bg=YELLOW, padx=50, pady=50)

# Canvas Section
canvas = Canvas(width=200, height=200)
canvas.config(bg=YELLOW, highlightthickness=0)

photo = PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=photo)
canvas.grid(row=0, column=1)

# Label Section
label_website = Label(text="Website : ", bg=YELLOW, font=(FONT_NAME, 12, "bold"))
label_website.grid(row=1, column=0)
label_username = Label(text="Email/Username : ", bg=YELLOW, font=(FONT_NAME, 12, "bold"))
label_username.grid(row=3, column=0)
label_password = Label(text="Password : ", bg=YELLOW, font=(FONT_NAME, 12, "bold"))
label_password.grid(row=5, column=0)

# Textbox Section
textbox_website = Entry(width=24, font=(FONT_NAME, 15))
textbox_website.config(bg="white")
textbox_website.focus()  # to put cursor in textbox when program is launched
textbox_website.grid(row=1, column=1)

textbox_username = Entry(width=35, font=(FONT_NAME, 15))
textbox_username.config(bg="white")
textbox_username.grid(row=3, column=1, columnspan=2)
textbox_username.insert(0, "ashwin2001nair@gmail.com")

textbox_password = Entry(width=24, font=(FONT_NAME, 15))
textbox_password.config(bg="white")
textbox_password.grid(row=5, column=1)

# Button Section
button_find = Button(text="Search", width=18, font=(FONT_NAME, 9, "bold"), command=find_password)
button_find.config(bg="white")
button_find.grid(row=1, column=2)

button_generate = Button(text="Generate Password", font=(FONT_NAME, 9, "bold"), command=create_password)
button_generate.config(bg="white")
button_generate.grid(row=5, column=2)

button_add = Button(text="Add", font=(FONT_NAME, 9, "bold"), width=60, command=save)
button_add.config(bg="white")
button_add.grid(row=7, column=1, columnspan=2)

# Creating Spaces
label_space_1 = Label(text="W : ", bg=YELLOW, fg=YELLOW, font=(FONT_NAME, 2, "bold"))
label_space_1.grid(row=2, column=0)

label_space_2 = Label(text="A : ", bg=YELLOW, fg=YELLOW, font=(FONT_NAME, 2, "bold"))
label_space_2.grid(row=4, column=0)

label_space_3 = Label(text="S : ", bg=YELLOW, fg=YELLOW, font=(FONT_NAME, 2, "bold"))
label_space_3.grid(row=6, column=0)

window.mainloop()
