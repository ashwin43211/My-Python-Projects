from turtle import Turtle

SHAPE = "circle"
COLOR = "white"


class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape(SHAPE)
        self.penup()
        self.shapesize(stretch_wid=1.0, stretch_len=1.0)
        self.color(COLOR)
        self.speed("fastest")
        self.goto(0, 0)
        self.x_move = 10
        self.y_move = 10
        self.refresh()
        self.move_speed = 0.10

    def refresh(self):
        x_cor = self.xcor() + self.x_move
        y_cor = self.ycor() + self.y_move
        self.goto(x_cor, y_cor)

    def reset_ball(self):
        self.goto(0, 0)
        self.bounce_paddel()
        self.move_speed = 0.10

    def bounce_wall(self):
        # this is used do that if it is moving +10,+10 so after bounce
        # it will move to opposite side and vice versa
        self.y_move *= -1

    def bounce_paddel(self):
        # this is used do that if it is moving +10,+10 so after bounce
        # it will move to opposite side and vice versa
        self.x_move *= -1
        self.move_speed *= 0.9
