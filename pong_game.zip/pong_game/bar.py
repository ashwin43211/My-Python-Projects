from turtle import Turtle, Screen

SPEED = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0
SHAPE = "square"
SIZE = 3


class Paddle(Turtle):
    def __init__(self, x_coordinate, y_coordinate):
        super().__init__()
        self.x_coordinate = x_coordinate
        self.y_coordinate = y_coordinate
        self.screen = Screen()
        self.create_paddle()

    def create_paddle(self):
        self.shape(SHAPE)
        self.color("white")
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.penup()
        self.goto(self.x_coordinate, self.y_coordinate)
        self.forward(20)

    def up(self):
        new_y = self.ycor() + 20
        self.goto(self.xcor(), new_y)

    def down(self):
        new_y = self.ycor() - 20
        self.goto(self.xcor(), new_y)
