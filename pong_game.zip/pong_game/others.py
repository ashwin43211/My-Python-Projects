from turtle import Turtle
import time

FONT = ("Arial", 16, "normal")
ALIGN = "center"


class WelcomeScreen(Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.goto(0, -50)

    def greetings(self):
        self.setposition(0, 80)
        self.write(f"To control left paddle, w to go up & s to go down ", True, align=ALIGN, font=FONT)
        self.setposition(0, 20)
        self.write(f"To control right paddle, 8 to go up & 2 to go down ", True, align=ALIGN, font=FONT)
        time.sleep(5)
        self.clear()

    def l_result(self):
        self.color("white")
        self.setposition(0, 80)
        self.write(f"Left won by : 10 points  ", True, align=ALIGN, font=FONT)
        time.sleep(5)
        self.clear()

    def r_result(self):
        self.color("white")
        self.setposition(0, 80)
        self.write(f"Right won by : 10 points  ", True, align=ALIGN, font=FONT)
        time.sleep(5)
        self.clear()
