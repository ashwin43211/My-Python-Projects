from turtle import Turtle, Screen
from bar import Paddle
from others import WelcomeScreen
from ball import Ball
from scoreboard import Scoreboard
import time

TITLE = "Pong"
FONT = ("Arial", 16, "normal")
ALIGN = "center"

ball = Ball()
screen = Screen()
turtle = Turtle()
welcome_screen = WelcomeScreen()
score = Scoreboard()

turtle.hideturtle()
welcome_screen.greetings()

is_game_over = False

screen.setup(width=800, height=600)
screen.bgcolor("black")  # background color
screen.title(TITLE)  # title of window
screen.tracer(0)

r_paddle = Paddle(x_coordinate=350, y_coordinate=0)
l_paddle = Paddle(x_coordinate=-395, y_coordinate=0)

l_paddle.create_paddle()
r_paddle.create_paddle()
score.update_score()

screen.listen()
screen.onkey(key="8", fun=r_paddle.up)
screen.onkey(key="2", fun=r_paddle.down)

screen.onkey(key="w", fun=l_paddle.up)
screen.onkey(key="s", fun=l_paddle.down)

while is_game_over is not True:
    time.sleep(ball.move_speed)
    screen.update()
    ball.refresh()

    # to check if the ball has crossed the border or not. If crossed then bounce.
    if ball.ycor() > 290 or ball.ycor() < -290:
        ball.bounce_wall()

    # This if statement is for checking if the ball touched the peddle. If yes then bounce
    if ball.distance(r_paddle) < 50 and ball.xcor() > 340 or ball.distance(l_paddle) < 50 and ball.xcor() < -340:
        ball.bounce_paddel()

    # to check if the right peddle missed, if missed then +1 for left
    if ball.xcor() > 380:
        turtle.clear()
        score.left_score()
        score.update_score()
        ball.reset_ball()

    # to check if the left peddle missed, if missed then +1 for right
    if ball.xcor() < -380:
        turtle.clear()
        score.right_score()
        score.update_score()
        ball.reset_ball()

    if score.left_point() == 10:
        welcome_screen.l_result()
        is_game_over = True
    elif score.right_point() == 10:
        welcome_screen.r_result()
        is_game_over = True

screen.exitonclick()

